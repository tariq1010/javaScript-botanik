export { default as HomeCom } from "./homeComp";
export { default as Navbar } from "./mainNavbar";
export { default as Footer } from "./mainFooter";
export { default as Blogs } from "./blogsComp";
export { default as AdminDashboardCom } from "./adminDashboard";
