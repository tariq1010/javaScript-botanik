import styled from "styled-components";

export const HomeCompWrapper = styled.div`
  overflow: hidden;
  min-height: 100vh;
  background-color: #fff;
`;
