const app = {
    OWNER_ADDRESS: "0xFdFC79512f8222BFC7eC6464b05dc0c4b615e1dF"
}

export  {
    app
}