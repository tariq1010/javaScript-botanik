declare module '*.png'
declare module '*.csv'