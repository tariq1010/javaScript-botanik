const environment = {
    LOGIN_USERNAME: "$2a$10$OcoCTqsVmxcrwPxs93ddbOI7cO1xp8s3FwJHOP9XO0tw6Ksx9KmvO",
    LOGIN_PASSWORD: "$2a$10$X13zLFuEUXpGmuwA/DgOQu4.FHfmcj1PFLcqooJLHkqY//0VY4yjK",
    ADMIN_NAME:"admin",
    ADMIN_PASSWORD:"123456"
  };
  
  export default environment;
  