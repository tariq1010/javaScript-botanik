import React from "react"


const SocialIcons = () => {

    return (
        <div className="icons">
            <a href="https://twitter.com/illowlsNFT" target="_blank">
                <i className="pi pi-twitter" ></i>
            </a>
            <a href="http://discord.gg/BFfBkHtU2P" target="_blank">
                <i className="pi pi-discord" ></i>
            </a>

        </div>
    )
}

export default SocialIcons