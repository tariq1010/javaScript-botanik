const environment = {
  BACKEND_BASE_URL: "https://nft.taperajungle.com",
  // BACKEND_BASE_URL: "https://botanik.buildmydapp.co",
  rpc: "https://mainnet.infura.io/v3/2b2b802ce8414591a6c76a30cf192ad3",
  PER_TXN_LIMIT: Number(200),
};

export default environment;
