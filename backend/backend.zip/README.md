## `how to start project with specific environment`
For development,staging,production like
npm run devv, npm run stag, npm run prod
The Build commands are,
npm run build-dev, npm run build:stag, npm run build:prod