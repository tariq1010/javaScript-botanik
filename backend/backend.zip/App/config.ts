const config = {
    MONGOOSE_URL: "mongodb+srv://test:test123@cluster0.1cezz.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    USER_TOKEN: "_secuRe@walLeton&apI2coNnect_4",
    RPC_URL: "https://goerli.infura.io/v3/2b2b802ce8414591a6c76a30cf192ad3",
    CLIENT_URL:"http://localhost:3000",
    ADMIN_TOKEN: '_secuReOwl@sweaslhLietMintingon&apI2coNnect_4',
    BACKEND_URL:"http://localhost:8080",
    PROJECT_NAME:"Botanic-",
    FILE_UPLOAD_PATH:"./public/uploads"
}



export = { config };